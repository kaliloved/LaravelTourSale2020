@include('front.includes.header')

<main role="main" class="container">
    @yield('content') 
</main>

@include('front.includes.footer')