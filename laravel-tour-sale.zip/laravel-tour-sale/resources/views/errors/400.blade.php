<html>
    <p>{{ $exception->getMessage() }}</p>
</html>