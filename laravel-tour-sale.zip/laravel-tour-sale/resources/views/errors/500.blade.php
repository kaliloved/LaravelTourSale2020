<html>
    <h1>error 500</h1>
    <p>{{ $exception->getMessage() }}</p>
</html>