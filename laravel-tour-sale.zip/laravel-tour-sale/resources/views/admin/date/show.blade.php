@extends('layout.admin') 
@section('content')
<h2>@lang('adminLang.date'): {{$date->tour->name}} </h2>
@endsection