<div class="ilan">
    <div class="row">
        <div class="col-2">
            <img src="holder.js/110x90">
        </div>
        <div class="col-10">
            <div class="row">
                <div class="col-12 pt-2">
                    <h6 class="font-weight-bold"><a href="{{route('ad.detail')}}">İlan Başlığı</a></h6>
                </div>
            </div>
            <br>
            <div class="row justify-content-between">
                <div class="col-5">
                    <i class="fa fa-calendar-o" aria-hidden="true"></i> 25 Şubat 2018
                </div>
                <div class="col-4">
                    <i class="fa fa-map-marker" aria-hidden="true"></i> Location
                </div>
                <div class="col-3">
                    <div class="price listing-price text-center">
                        €8.300
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="ilan-line"></div>
</div>