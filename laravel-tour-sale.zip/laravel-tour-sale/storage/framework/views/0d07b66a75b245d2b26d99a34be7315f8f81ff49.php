 <?php if($flash = session('flash')): ?> 
    <div class="flash">
            <div class="alert alert-<?php echo e($flash['status']); ?>" role="alert"><?php echo e($flash['message']); ?></div>
    </div>
<?php endif; ?>