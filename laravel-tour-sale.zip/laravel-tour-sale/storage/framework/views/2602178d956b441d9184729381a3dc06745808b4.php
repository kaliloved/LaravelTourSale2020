<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php if(isset($pageTitle)): ?>
        <title><?php echo e($pageTitle); ?></title>
    <?php else: ?>
        <title>Toursale with Laravel</title>
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>" >
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/lightslider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/slick/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/slick/slick-theme.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('header_js'); ?>
</head>
<body>
    <div class="container">

        <header class="blog-header py-3">
            <div class="row flex-nowrap justify-content-between align-items-center">
                <div class="col-4 pt-1">
                </div>
                <div class="col-4 text-center">
                    <a href="<?php echo e(route('home')); ?>">
                        <h1 class="header-title">Toursale</h1>
                    </a>
                </div>
                <div class="col-4 d-flex justify-content-end align-items-center">
                    
                </div>
            </div>
        </header>

        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <div class="nav-scroller py-1 mb-5" style="">
                    <nav class="nav d-flex">
                        <?php if(isset($categories)): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="p-3 text-muted" href="<?php echo e(route('category', [$category->id])); ?>"><?php echo e($category->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                            <a class="p-3 text-muted" href="<?php echo e(route('admin.category.index')); ?>">Admin Panel</a>
                        <?php else: ?>
                            <a class="p-3 text-muted" href="<?php echo e(route('login')); ?>">Admin Login</a>
                        <?php endif; ?>
                    </nav>
                </div>
   
            </div>
        </div>
        </div>


     

