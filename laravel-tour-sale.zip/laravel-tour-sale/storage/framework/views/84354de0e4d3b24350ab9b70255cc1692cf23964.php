 

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-8">
            <h2>Popular Tours</h2>
            <div class="popularTours">
                <div class="row">
                    <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $tourDetailLink = route('tour', [$popular->id]) 
                    ?>
                        <div class="col-4 border">
                            <a href="<?php echo e($tourDetailLink); ?>">
                                <div class="img-box">
                                    <?php if(isset($popular->photos[0])): ?>
                                    <img width="200" src="<?php echo e(asset('storage/' . $popular->photos[0]->filename_thumb )); ?>">
                                    <?php else: ?>
                                    <img src="holder.js/200x123">
                                    <?php endif; ?>
                                    <div class="title-on-image">
                                        <?php echo e(str_limit($popular->name, 30)); ?>

                                    </div>
                                </div>
                            </a>
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>



        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>