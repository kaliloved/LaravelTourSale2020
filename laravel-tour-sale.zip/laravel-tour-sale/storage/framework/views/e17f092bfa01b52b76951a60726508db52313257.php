<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
      <h1 class="h2"><?php echo app('translator')->getFromJson('adminLang.reservations'); ?></h1>
      <div class="btn-toolbar mb-2 mb-md-0">
        
        <div class="btn-group mr-2">
        </div>
      </div>
    </div>

    <div class="">
        <table id="datatable" class="table table-striped table-bordered" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminLang.reservation_id'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.payment'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.tour_name'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.contact_name'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.amount'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.update'); ?></th>
              <th width="100" class="text-right"><?php echo app('translator')->getFromJson('adminLang.actions'); ?></th>

            </tr>
          </thead>
          <tbody>
            <?php if($records): ?>
              <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($record->id); ?></td>
                  <td>
                    <?php if($record->payment_status == 1): ?>
                      <span class="badge badge-success">Received</span> <?php else: ?>
                      <span class="badge badge-secondary">Not Received</span> <?php endif; ?>
                  </td>
                  <td><?php echo e($record->tour->name); ?></td>
                  <td><?php echo e($record->contact->name); ?></td>
                  <td><?php echo e($record->total_price); ?> <?php echo e($record->currency); ?></td>
                  <td><?php echo e($record->updated_at->format('d-m-Y H:i:s')); ?></td>
                  <td class="text-right">
                    <a href="<?php echo e(route($baseRoute . '.show', [$record->id])); ?> " class="btn btn-primary btn-sm"><?php echo app('translator')->getFromJson('adminLang.show'); ?></a>
                    <a href="<?php echo e(route($baseRoute . '.delete', [$record->id])); ?> " class="btn btn-danger btn-sm"><?php echo app('translator')->getFromJson('adminLang.delete'); ?></a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          </tbody>
        </table>

        <?php if(count($records) == 0): ?>
        <p><?php echo app('translator')->getFromJson('adminLang.not-found'); ?></p>
        <?php endif; ?>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
  
  <link href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script>
    $(document).ready(
      function(){ 
        $('#datatable').DataTable(); 
      });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>