<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>TourSale Panel</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>" >
    
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
        <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="<?php echo e(route('admin.dashboard')); ?>">TourSale with Laravel</a>
        <ul class="navbar-nav px-3">
            <li class="nav-item text-nowrap">
            <form class="form-inline" method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo e(csrf_field()); ?>

                    
                    <button type="submit" class="btn btn-secondary"><?php echo app('translator')->getFromJson('adminLang.logout'); ?></button>
                </form>
            </li>
        </ul>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                <span data-feather="home"></span>
                                <?php echo app('translator')->getFromJson('adminLang.dashboard'); ?> <span class="sr-only">(current)</span>
                            </a>
                        </li>
                    </ul>
                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span><?php echo app('translator')->getFromJson('adminLang.admin-panel'); ?></span>
                        <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle"></span>
              </a>
                    </h6>
                    <ul class="nav flex-column mb-2">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('home')); ?>" target="_blank"><?php echo app('translator')->getFromJson('adminLang.show-website'); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.category.index')); ?>">
                                <span data-feather="file-text"></span>
                                <?php echo app('translator')->getFromJson('adminLang.categories'); ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.tour.index')); ?>">
                                <span data-feather="file-text"></span>
                                <?php echo app('translator')->getFromJson('adminLang.tour'); ?>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.reservation.index')); ?>">
                                <span data-feather="file-text"></span>
                                <?php echo app('translator')->getFromJson('adminLang.reservations'); ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.payment.index')); ?>">
                                <span data-feather="file-text"></span>
                                <?php echo app('translator')->getFromJson('adminLang.payments'); ?>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            <main role="main" class="main col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">

                    <div class="row">
                        <div class="col-6">
                            <?php echo $__env->make('admin.inc.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php echo $__env->make('admin.inc.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>

                    <?php echo $__env->yieldContent('content'); ?> 
                
            </main>
        </div>
    </div>



    
    
</body>


    <script src="<?php echo e(asset('js/jquery-3.3.1.slim.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/holder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('css/summernote/summernote-bs4.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $('#summernote').summernote({
                height: 300
            });
            $('#summernote-short').summernote({
                height: 100
            });
            // enable popovers
            $(function () { $('[data-toggle="popover"]').popover() })
            // enable popovers
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</html>