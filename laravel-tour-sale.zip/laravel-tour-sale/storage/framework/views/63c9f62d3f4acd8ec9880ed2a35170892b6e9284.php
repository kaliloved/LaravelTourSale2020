 <?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-8">
        <?php echo $__env->make('front.includes.tour_info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <h4><?php echo app('translator')->getFromJson('frontLang.dates'); ?></h4>
        <?php if(isset($dates)): ?>
        <table class="table">
            <thead>
                <th><?php echo app('translator')->getFromJson('frontLang.start-date'); ?></th>
                <th><?php echo app('translator')->getFromJson('frontLang.finish-date'); ?></th>
                <th><?php echo app('translator')->getFromJson('frontLang.price'); ?></th>
                <th><?php echo app('translator')->getFromJson('frontLang.single-price'); ?></th>
                <th><?php echo app('translator')->getFromJson('frontLang.actions'); ?></th>
            </thead>
            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($date->start_date->format('d/m/Y')); ?></td>
                <td><?php echo e($date->end_date->format('d/m/Y')); ?></td>
                <td><?php echo e($date->price); ?> <?php echo e($date->currency); ?></td>
                <td><?php echo e($date->single_price); ?> <?php echo e($date->currency); ?></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('reservation.selectpax', [$date->id])); ?>" role="button"><?php echo app('translator')->getFromJson('frontLang.make-reservation'); ?></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>