<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
      <h1 class="h2"><?php echo app('translator')->getFromJson('adminLang.tours'); ?></h1>
      <div class="btn-toolbar mb-2 mb-md-0">
        
        <div class="btn-group mr-2">
        <a href="<?php echo e(route('admin.tour.create')); ?>" class="btn btn-sm btn-outline-secondary">+ <?php echo app('translator')->getFromJson('adminLang.new'); ?></a>
        </div>
      </div>
    </div>

    <div class="">
        <table id="datatable" class="table table-striped table-bordered" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>#</th>
              <th><?php echo app('translator')->getFromJson('adminLang.status'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.name'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.dates'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.category'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.photos'); ?></th>
              <th><?php echo app('translator')->getFromJson('adminLang.update'); ?></th>
              <th width="200" class="text-right"><?php echo app('translator')->getFromJson('adminLang.actions'); ?></th>

            </tr>
          </thead>
          <tbody>
            <?php if($records): ?>
              <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($record->id); ?></td>
                  <td><?php if($record->status == 1): ?> 
                        <span class="badge badge-success"><?php echo app('translator')->getFromJson('adminLang.published'); ?></span>
                      <?php elseif($record->status == 0): ?> 
                        <span class="badge badge-danger"><?php echo app('translator')->getFromJson('adminLang.unpublished'); ?></span>
                      <?php elseif($record->status == 2): ?> 
                        <span class="badge badge-warning"><?php echo app('translator')->getFromJson('adminLang.draft'); ?></span>   
                      <?php endif; ?></td>
                  <td><?php echo e($record->name); ?></td>
                  <td class="text-center">
                      <button class="btn btn-info btn-sm" data-toggle="popover" data-placement="top" data-html="true" 
                    data-content="
                    <?php if(isset($record->dates)): ?>
                      <?php $__currentLoopData = $record->dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($item->start_date->format('d.m.Y')); ?> - <?php echo e($item->end_date->format('d.m.Y')); ?> <br />
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  
                    ">
                        <?php echo e($record->dates_count); ?> 
                      </button>
                      <a href="<?php echo e(route('admin.date.index', [$record->id])); ?>" class="btn btn-warning btn-sm"><?php echo app('translator')->getFromJson('adminLang.edit'); ?></a>
                  </td>
                  <td><?php echo e($record->category->name ?? '...'); ?></td>
                <td class="text-center">
                  <?php
                    $count = $record->photos->count()
                  ?>
                  
                  <?php if($count == 0 ): ?> <b><?php echo app('translator')->getFromJson('adminLang.no-photos'); ?></b> <?php else: ?> <?php echo e($count); ?> <?php endif; ?> </td>
                  <td><?php echo e($record->updated_at->format('d.m.y')); ?></td>
                  <td class="text-right">
                    <a href="<?php echo e(route($baseRoute . '.show', [$record->id])); ?> " class="btn btn-primary btn-sm"><?php echo app('translator')->getFromJson('adminLang.show'); ?></a>
                    <a href="<?php echo e(route($baseRoute . '.edit', [$record->id])); ?> " class="btn btn-warning btn-sm"><?php echo app('translator')->getFromJson('adminLang.edit'); ?></a>
                    <a href="<?php echo e(route($baseRoute . '.delete', [$record->id])); ?> " class="btn btn-danger btn-sm"><?php echo app('translator')->getFromJson('adminLang.delete'); ?></a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          </tbody>
        </table>

        <?php if(count($records) == 0): ?>
        <p><?php echo app('translator')->getFromJson('adminLang.not-found'); ?></p>
        <a name="" id="" class="btn btn-success btn-sm" href="<?php echo e(route( $baseRoute . '.create')); ?>" role="button"><?php echo app('translator')->getFromJson('adminLang.new'); ?></a>
        <?php endif; ?>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
  
  <link href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script>
    $(document).ready(
      function(){ 
        $('#datatable').DataTable(); 
      });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>