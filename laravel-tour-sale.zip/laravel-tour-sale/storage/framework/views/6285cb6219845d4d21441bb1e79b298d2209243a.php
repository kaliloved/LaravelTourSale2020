 <?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <h2><?php echo e($category->name); ?></h2>
        <?php if(isset($tours)): ?>
        <ul class="tour-list">
            <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $tourDetailLink = route('tour', [$tour->id]) ?>
            <li class="border">
                <div class="row">
                    <div class="col-4">
                        <?php if(isset($tour->photos[0])): ?>
                        <a href="<?php echo e($tourDetailLink); ?>">
                            <img width="200" src="<?php echo e(asset('storage/' . $tour->photos[0]->filename_thumb )); ?>"> 
                        </a>
                        <?php else: ?>
                            <img src="holder.js/170x200"> 
                        <?php endif; ?>
                    </div>
                    <div class="col-8">
                        <h5>
                            <a href="<?php echo e($tourDetailLink); ?>"><?php echo e($tour->name); ?></a>
                        </h5>
                        <p><?php echo $tour->summary; ?></p>
                        <p>
                            <a name="" id="" class="btn btn-primary" href="<?php echo e($tourDetailLink); ?>" role="button"><?php echo app('translator')->getFromJson('frontLang.show-dates'); ?></a>
                        </p>
                    </div>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>