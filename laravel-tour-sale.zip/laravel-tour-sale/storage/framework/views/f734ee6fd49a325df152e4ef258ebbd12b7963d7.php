 
<?php $__env->startSection('content'); ?>
<h2><?php echo app('translator')->getFromJson('adminLang.category'); ?>: <?php echo e($record->name); ?> </h2>

<div class="row">
    <div class="col-6">
        <table class="table table-hover">
            <tr>
                <td>
                    <?php echo app('translator')->getFromJson('adminLang.category-name'); ?>
                </td>
                <td>
                    <?php echo e($record->name); ?>

                </td>
            </tr>
            <tr>
                <td>
                    <?php echo app('translator')->getFromJson('adminLang.status'); ?>
                </td>
                <td>
                    <?php echo e($record->status); ?>

                </td>
            </tr>
            <tr>
                <td>
                    <?php echo app('translator')->getFromJson('adminLang.category-seo-name'); ?>
                </td>
                <td>
                    <?php echo e($record->slug); ?>

                </td>
            </tr>
            <tr>
                <td>
                    <?php echo app('translator')->getFromJson('adminLang.description'); ?>
                </td>
                <td>
                    <?php echo e($record->description); ?>

                </td>
            </tr>
        </table>
    </div>
</div>

<p>
    <a href="<?php echo e(route($baseRoute . '.index')); ?> " class="btn btn-primary btn-sm"><?php echo app('translator')->getFromJson('adminLang.back'); ?></a>
    <a href="<?php echo e(route($baseRoute . '.edit', ['id' => $record->id])); ?> " class="btn btn-warning btn-sm"><?php echo app('translator')->getFromJson('adminLang.edit'); ?></a>
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>