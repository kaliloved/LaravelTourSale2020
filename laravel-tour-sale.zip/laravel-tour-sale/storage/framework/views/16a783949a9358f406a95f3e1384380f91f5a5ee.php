<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
      <h1 class="h2"><?php echo app('translator')->getFromJson('adminLang.categories'); ?></h1>
      <div class="btn-toolbar mb-2 mb-md-0">
        
        <div class="btn-group mr-2">
        <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-sm btn-outline-secondary">+ <?php echo app('translator')->getFromJson('adminLang.new'); ?></a>
        </div>
        
      </div>
    </div>

    <div class="controls">
      <form method="get">
        <div class="search-form">
          <div class="row">

            <div class="col-3">
              <input type="text" class="form-control" name="q" value="<?php echo e($q); ?>" placeholder="<?php echo app('translator')->getFromJson('adminLang.search'); ?>...">
            </div>
    
            <div class="col-2">
              <button type="submit" class="btn btn-primary btn-sm"><?php echo app('translator')->getFromJson('adminLang.apply-filter'); ?></button>
            </div>
          </div>
          <input type="hidden" name="o" value="<?php echo e($o); ?>"></input>
        </div>
      </form>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
              <th><a href="?q=<?php echo e($q); ?>&o=<?php echo $o == 40 ? "41" : "40";?>"><?php echo app('translator')->getFromJson('adminLang.status'); ?> </a></th>
              <th><a href="?q=<?php echo e($q); ?>&o=<?php echo $o == 10 ? "11" : "10";?>"><?php echo app('translator')->getFromJson('adminLang.name'); ?> </a></th>
              <th><a href="?q=<?php echo e($q); ?>&o=<?php echo $o == 20 ? "21" : "20";?>"><?php echo app('translator')->getFromJson('adminLang.add'); ?></a></th>
              <th><a href="?q=<?php echo e($q); ?>&o=<?php echo $o == 30 ? "31" : "30";?>"><?php echo app('translator')->getFromJson('adminLang.update'); ?> </a></th>
              <th><?php echo app('translator')->getFromJson('adminLang.actions'); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php if($records): ?>
              <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($record->id); ?></td>
                  <td><?php if($record->status): ?> <?php echo app('translator')->getFromJson('adminLang.published'); ?> <?php else: ?> <?php echo app('translator')->getFromJson('adminLang.unpublished'); ?> <?php endif; ?></td>
                  <td><?php echo e($record->name); ?></td>
                  <td><?php echo e($record->created_at->format('d.m.y')); ?></td>
                  <td><?php echo e($record->updated_at->format('d.m.y')); ?></td>
                  <td>
                    <a href="<?php echo e(route($baseRoute . '.show', [$record->id])); ?> " class="btn btn-primary btn-sm"><?php echo app('translator')->getFromJson('adminLang.show'); ?></a>
                    <a href="<?php echo e(route($baseRoute . '.edit', [$record->id])); ?> " class="btn btn-warning btn-sm"><?php echo app('translator')->getFromJson('adminLang.edit'); ?></a>
                    <a href="<?php echo e(route($baseRoute . '.delete', [$record->id])); ?> " class="btn btn-danger btn-sm"><?php echo app('translator')->getFromJson('adminLang.delete'); ?></a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          </tbody>
        </table>

        <?php if(count($records) == 0): ?>
        <p><?php echo app('translator')->getFromJson('adminLang.not-found'); ?></p>
        <a name="" id="" class="btn btn-success btn-sm" href="<?php echo e(route( $baseRoute . '.create')); ?>" role="button"><?php echo app('translator')->getFromJson('adminLang.new'); ?></a>
        <?php endif; ?>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>