<?php $__env->startSection('content'); ?>
    <h2><?php echo app('translator')->getFromJson('adminLang.date'); ?> <?php echo app('translator')->getFromJson('adminLang.create'); ?></h2>
    
    <div class="row">
        <div class="col-6">
        <form method="POST" action="<?php echo e(route($baseRoute . '.store', [$tour->id])); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group" style="width: 50%">
                  <label for="status"><?php echo app('translator')->getFromJson('adminLang.status'); ?></label>
                  <select class="form-control" name="status" id="status">
                    <option value="1"><?php echo app('translator')->getFromJson('adminLang.published'); ?></option>
                    <option value="0"><?php echo app('translator')->getFromJson('adminLang.unpublished'); ?></option>
                  </select>
                </div>
                <div class="form-group">
                    <label for="name"><?php echo app('translator')->getFromJson('adminLang.tour-name'); ?></label>
                    <p><?php echo e($tour->name); ?></p>
                </div>
                <div class="form-group">
                    <label for="slug"><?php echo app('translator')->getFromJson('adminLang.start-date'); ?></label>
                    <input type="date" name="start_date" class="form-control">
                </div>
                <div class="form-group">
                    <label for="summernote"><?php echo app('translator')->getFromJson('adminLang.finish-date'); ?> </label>
                    <input type="date" name="end_date" class="form-control">
                </div>
                <div class="form-group">
                  <label for="min-participant"><?php echo app('translator')->getFromJson('adminLang.mix-pax'); ?></label>
                  <input type="number" name="min_pax" id="min_pax" class="form-control">
                </div>
                <div class="form-group">
                  <label for="max-participant"><?php echo app('translator')->getFromJson('adminLang.max-pax'); ?></label>
                  <input type="number" name="max_pax" id="max_pax" class="form-control">
                </div>
                <div class="form-group">
                  <label for="currency"><?php echo app('translator')->getFromJson('adminLang.currency'); ?></label>
                  <select class="form-control" name="currency" id="currency">
                    <option value="TRY">TRY</option>
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                  </select>
                </div> 
                <div class="form-group">
                  <label for="price"><?php echo app('translator')->getFromJson('adminLang.price'); ?></label>
                  <input type="number" name="price" id="price" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('adminLang.save'); ?></button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary"><?php echo app('translator')->getFromJson('adminLang.cancel'); ?></a>
                <input type="hidden" name="previous" value="<?php echo e(url()->previous()); ?>">
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>