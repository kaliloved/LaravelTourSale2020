<?php $__env->startSection('content'); ?>
    <h2><?php echo app('translator')->getFromJson('adminLang.category'); ?> <?php echo app('translator')->getFromJson('adminLang.edit'); ?></h2>
    <div class="row">
        <div class="col-6">
        <form method="POST" action="<?php echo e(route($baseRoute . '.update', ['category' => $category->id])); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group" style="width: 50%">
                  <label for="status"><?php echo app('translator')->getFromJson('adminLang.status'); ?></label>
                  <select class="form-control" name="status" id="status">
                    <option value="1" <?php if($category->status == 1): ?> selected <?php endif; ?> ><?php echo app('translator')->getFromJson('adminLang.published'); ?></option>
                    <option value="0" <?php if($category->status == 0): ?> selected <?php endif; ?> ><?php echo app('translator')->getFromJson('adminLang.unpublished'); ?></option>
                  </select>
                </div>
                <div class="form-group">
                    <label for="name"><?php echo app('translator')->getFromJson('adminLang.category-name'); ?></label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($category->name); ?>" autofocus required>
                </div>
                <div class="form-group">
                    <label for="slug"><?php echo app('translator')->getFromJson('adminLang.category-seo-name'); ?></label>
                    <input type="text" class="form-control" id="slug" name="slug" value="<?php echo e($category->slug); ?>">
                </div>
                <div class="form-group">
                    <label for="summernote"><?php echo app('translator')->getFromJson('adminLang.description'); ?></label>
                    <textarea id="summernote" name="description"><?php echo $category->description; ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('adminLang.save'); ?></button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary"><?php echo app('translator')->getFromJson('adminLang.cancel'); ?></a>

                <input type="hidden" name="previous" value="<?php echo e(url()->previous()); ?>">
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>