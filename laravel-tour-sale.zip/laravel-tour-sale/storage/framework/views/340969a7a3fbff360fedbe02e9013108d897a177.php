<div class="tour-info">
    <h2><?php echo e($tour->name); ?></h2>

    <?php if('tour' === \Request::route()->getName()): ?>
        <ul id="lightSlider">
        <?php $__empty_1 = true; $__currentLoopData = $tour->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <img src="<?php echo e(asset('storage/' . $photo->filename )); ?>">
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li>
                    <img src="holder.js/325x200"> 
                </li>
            <?php endif; ?>
        </ul>

    <div class="summary"><?php echo $tour->summary; ?></div>
    <?php endif; ?>
</div>