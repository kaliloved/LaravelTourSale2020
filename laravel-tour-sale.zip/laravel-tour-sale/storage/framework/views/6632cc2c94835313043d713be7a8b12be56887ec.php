<?php $__env->startSection('content'); ?>
    <h2><?php echo app('translator')->getFromJson('adminLang.tour'); ?> <?php echo app('translator')->getFromJson('adminLang.edit'); ?></h2>

<div class="row">
    <div class="col-6">
        <form method="POST" action="<?php echo e(route($baseRoute . '.update', ['tour' => $tour->id])); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label for="status"><?php echo app('translator')->getFromJson('adminLang.status'); ?></label>
                        <select class="form-control" name="status" id="status">
                            <option value="1" <?php if($tour->status == 1): ?> selected <?php endif; ?> ><?php echo app('translator')->getFromJson('adminLang.published'); ?></option>
                            <option value="0" <?php if($tour->status == 0): ?> selected <?php endif; ?> ><?php echo app('translator')->getFromJson('adminLang.unpublished'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="name"><?php echo app('translator')->getFromJson('adminLang.category'); ?></label>
                        <select name="category_id" id="category_id" class="form-control">
                            <option value="0">...</option>
                            <?php if(isset($categories)): ?> 
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php if($tour->category_id == $category->id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="col-6"></div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label for="name"><?php echo app('translator')->getFromJson('adminLang.tour-name'); ?></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($tour->name); ?>" autofocus required>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label for="slug"><?php echo app('translator')->getFromJson('adminLang.tour-name-seo'); ?></label>
                        <input type="text" class="form-control" id="slug" name="slug" value="<?php echo e($tour->slug); ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label for="summernote"><?php echo app('translator')->getFromJson('adminLang.tour-desc-short'); ?> </label>
                        <textarea id="summernote-short" name="summary"><?php echo e($tour->summary); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label for="summernote"><?php echo app('translator')->getFromJson('adminLang.tour-desc'); ?></label>
                        <textarea id="summernote" name="description"><?php echo e($tour->description); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">

                </div>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('adminLang.save'); ?></button>
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary"><?php echo app('translator')->getFromJson('adminLang.cancel'); ?></a>

            <input type="hidden" name="previous" value="<?php echo e(url()->previous()); ?>">
        </form>
    </div>
    <div class="col-6">
        <h4><?php echo app('translator')->getFromJson('adminLang.photos'); ?></h4>
        <div id="app">
            <photo-upload-component url="<?php echo e(url('/')); ?>" record_id="<?php echo e($tour->id); ?>"></photo-upload-component>
            <input type="hidden" name="csrf-token" value="<?php echo e(csrf_token()); ?>">
        </div>
    </div>
</div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>